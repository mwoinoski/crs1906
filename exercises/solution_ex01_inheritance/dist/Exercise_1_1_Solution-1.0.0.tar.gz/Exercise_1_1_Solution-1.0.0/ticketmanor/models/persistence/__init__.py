__author__ = 'Mike Woinoski (mike@articulatedesign.us.com)'


class PersistenceError(ValueError):
    """Exception class for invalid entity ids, etc."""
    pass
