TicketManor README
==================

Getting Started
---------------

- cd <directory containing this file>

- %VENV%/Scripts/python setup.py develop

- %VENV%/Scripts/pserve development.ini --reload

- View a welcome page at http://localhost:6543/
