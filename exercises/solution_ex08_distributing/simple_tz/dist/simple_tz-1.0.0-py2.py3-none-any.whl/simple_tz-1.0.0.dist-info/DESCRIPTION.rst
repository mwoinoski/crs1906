########
Overview
########

TODO: add a description of the simple_tz package here

``simple_tz`` defines a simple wrapper for the time conversion functions
in ``pytz``.


