########
Overview
########

This is a sample project that demonstrates the use of the ``setuptools``
module and its ``setup()`` function.

Notes
=====

#. It uses ``setuptools`` instead of ``distutils``
#. It includes examples in the ``examples`` directory

For an introduction to **reStructuredText**,
see http://sphinx-doc.org/rest.html