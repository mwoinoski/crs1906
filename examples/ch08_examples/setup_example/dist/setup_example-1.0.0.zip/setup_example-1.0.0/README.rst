########
Overview
########

This is a sample project that demonstrates the use of the ``setuptools``
module and its ``setup()`` function.
