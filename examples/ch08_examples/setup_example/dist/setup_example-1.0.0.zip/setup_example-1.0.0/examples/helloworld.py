"""
An example usage of the packages, modules, and functions in this project.
"""


from setup_example.sample_mod1 import func1
from setup_example.sample_mod2 import func2


print("In " + __file__)
func1()
func2()
