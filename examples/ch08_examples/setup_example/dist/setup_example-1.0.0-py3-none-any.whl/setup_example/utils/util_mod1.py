"""
Utility module 1
"""


def util_func1():
    print("In {}.util_func1()".format(__name__))
