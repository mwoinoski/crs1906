"""
Utility module 2
"""


def util_func2():
    print("In {}.util_func1()".format(__name__))
